//
//  AppDelegate.h
//  FindMyRestaurent
//
//  Created by Muthuraj M on 1/21/15.
//  Copyright (c) 2015 Market Simplified. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

