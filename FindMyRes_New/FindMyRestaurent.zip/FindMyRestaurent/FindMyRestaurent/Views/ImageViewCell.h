//
//  ImageViewCell.h
//  Photomania
//
//  Created by Muthuraj M on 12/21/14.
//  Copyright (c) 2014 Market Simplified. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageViewCell : UITableViewCell

- (void)updateViewsWithData:(NSDictionary *)resDetails;

@end
