//
//  Journey.m
//  TrackMyDevice
//
//  Created by Muthuraj M on 2/22/15.
//  Copyright (c) 2015 Muthuraj Muthulingam. All rights reserved.
//

#import "Journey.h"


@implementation Journey

@dynamic distance;
@dynamic duration;
@dynamic timestamp;
@dynamic location;

@end
