//
//  Location.m
//  TrackMyDevice
//
//  Created by Muthuraj M on 2/22/15.
//  Copyright (c) 2015 Muthuraj Muthulingam. All rights reserved.
//

#import "Location.h"
#import "Journey.h"


@implementation Location

@dynamic latitude;
@dynamic longitiude;
@dynamic timestamp;
@dynamic journey;

@end
